package com.example.Bootcamp.SinauKoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootcampSinauKodingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootcampSinauKodingApplication.class, args);
	}

}
