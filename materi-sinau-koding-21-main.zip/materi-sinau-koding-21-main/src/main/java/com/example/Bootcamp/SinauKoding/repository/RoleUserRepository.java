package com.example.Bootcamp.SinauKoding.repository;

import com.example.Bootcamp.SinauKoding.model.RoleUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleUserRepository extends JpaRepository<RoleUser, Integer> {
}
