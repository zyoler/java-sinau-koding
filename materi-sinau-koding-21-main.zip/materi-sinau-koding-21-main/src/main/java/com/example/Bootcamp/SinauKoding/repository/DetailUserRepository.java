package com.example.Bootcamp.SinauKoding.repository;

import com.example.Bootcamp.SinauKoding.model.DetailUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetailUserRepository extends JpaRepository<DetailUser, Integer> {
}
