package com.example.Bootcamp.SinauKoding.model.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AuthResponseDTO {
    private String username;
    private String token;
}
