package com.sinaukoding21.belajar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelajarApplicationTests {

	@Test
	void contextLoads() {
	}

}
