package com.sinaukoding21.belajar.repositoy;

import com.sinaukoding21.belajar.model.Pembeli;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PembeliRepository extends JpaRepository<Pembeli,Integer> {
}
